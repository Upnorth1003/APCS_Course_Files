package Module15.Mod15Assignments.Assignment1505;

/**
 * @author Tyler
 * @version 3/12/2017
 * @purpose
 */
public class Car extends Vehicle
    {

        public Car(String name, double cost)
            {
                super(name, cost);
            }

    }
