package Module15.Mod15Assignments.Assignment1505;

/**
 * @author Tyler
 * @version 3/12/2017
 * @purpose
 */
public interface Product
    {

        public abstract String getName();
        public abstract double getCost();

    }
