package Module13.Mod13Assignments.Assignment1301;

/**
 * @author Tyler
 * @version 2/8/2017
 * @purpose calc sides with one double input
 */
public class Equilateral extends Triangle
    {
        Equilateral(double sides)
            {
                super(sides, sides, sides);
            }
    }
