package Module13.Mod13Assignments.Assignment1301;

/**
 * @author Tyler
 * @version 2/8/2017
 * @purpose calc cube sides with one int input
 */
public class Cube extends Box
    {
        Cube(int sides)
            {
                super(sides, sides, sides);
            }
    }
